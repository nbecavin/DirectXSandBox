�2000 3dplants.com

Model created by Drew Costigan

For a UV mapped .jpg textured version of this model, check out the 3dplants.com Archive CD...only $14.95! Includes DXF, OBJ, 3DS, LWO formats, textures, and UV templates. Visit www.3dplants.com for more information.

This model is free for commercial or non-commercial use, however, unauthorized sale or commercial distribution of this model in any form is prohibited. Please distribute the file only in it's original unmodified zipped format with this copyright text intact.


Check out these additional 3dplants.com products:


3D PLANT MODEL LIBRARY - VOLUME 1...

GRASSES AND GROUNDCOVER PLANTS
HEDGES AND BORDER PLANTS
ORNAMENTAL PLANTS
TROPICAL PLANTS AND TREES

______________________________________

3D PLANT MODEL LIBRARY - VOLUME 2...

CACTI AND DESERT PLANTS
HEDGES AND BORDER PLANTS
ORNAMENTAL FLOWERS
TREES AND STUMPS


CUSTOM 3D MODEL DESIGN SERVICES AVAILABLE, CONTACT:
support@3dplants.com or drew@drewcostigan.com

For Illustration, Animation, Graphic & Multimedia Design services, visit:
www.drewcostigan.com


*******

www.3dplants.com
